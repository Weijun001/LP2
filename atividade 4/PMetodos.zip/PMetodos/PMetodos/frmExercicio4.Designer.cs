﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxt = new System.Windows.Forms.RichTextBox();
            this.btnNumerico = new System.Windows.Forms.Button();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.btnAlfabetico = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxt
            // 
            this.rchTxt.Location = new System.Drawing.Point(167, 30);
            this.rchTxt.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.rchTxt.MaxLength = 100;
            this.rchTxt.Name = "rchTxt";
            this.rchTxt.Size = new System.Drawing.Size(467, 163);
            this.rchTxt.TabIndex = 0;
            this.rchTxt.Text = "";
            // 
            // btnNumerico
            // 
            this.btnNumerico.Location = new System.Drawing.Point(115, 276);
            this.btnNumerico.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnNumerico.Name = "btnNumerico";
            this.btnNumerico.Size = new System.Drawing.Size(125, 84);
            this.btnNumerico.TabIndex = 1;
            this.btnNumerico.Text = "Numérico";
            this.btnNumerico.UseVisualStyleBackColor = true;
            this.btnNumerico.Click += new System.EventHandler(this.btnNumerico_Click);
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.Location = new System.Drawing.Point(310, 276);
            this.btnEspacoBranco.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(175, 84);
            this.btnEspacoBranco.TabIndex = 2;
            this.btnEspacoBranco.Text = "Posição Primeiro Espaço em Branco";
            this.btnEspacoBranco.UseVisualStyleBackColor = true;
            this.btnEspacoBranco.Click += new System.EventHandler(this.btnEspacoBranco_Click);
            // 
            // btnAlfabetico
            // 
            this.btnAlfabetico.Location = new System.Drawing.Point(549, 276);
            this.btnAlfabetico.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnAlfabetico.Name = "btnAlfabetico";
            this.btnAlfabetico.Size = new System.Drawing.Size(125, 84);
            this.btnAlfabetico.TabIndex = 3;
            this.btnAlfabetico.Text = "Alfabético";
            this.btnAlfabetico.UseVisualStyleBackColor = true;
            this.btnAlfabetico.Click += new System.EventHandler(this.btnAlfabetico_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1333, 658);
            this.Controls.Add(this.btnAlfabetico);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.btnNumerico);
            this.Controls.Add(this.rchTxt);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxt;
        private System.Windows.Forms.Button btnNumerico;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button btnAlfabetico;
    }
}