﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonMenos_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out numero1) &&
                double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números Inválidos");
        }

        private void buttonVezes_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out numero1) &&
                double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números Inválidos");
        }

        private void buttonDividir_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out numero1) &&
                double.TryParse(txtNum2.Text, out numero2))
            {
                if (numero2 == 0)
                    MessageBox.Show("Não pode dividir por 0");
                else
                {
                    resultado = numero1 / numero2;
                    txtResultado.Text = resultado.ToString();
                }
            }
            else
                MessageBox.Show("Números Inválidos");
        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {
            this.Focus();
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();
        }

        private void buttonMais_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out numero1) &&
                double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 + numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números Inválidos");
        }
    }
}
