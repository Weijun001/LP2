﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            double lado1, lado2, lado3;

            if (double.TryParse(txtL1.Text, out lado1) &&
                double.TryParse(txtL2.Text, out lado2) &&
                double.TryParse(txtL3.Text, out lado3))
            {
                if (lado1 != lado2 && lado1 != lado3 && lado2 != lado3)
                {
                    MessageBox.Show("Triângulo Escaleno!");
                }
                else
                    if (lado1 == lado2 && lado2 == lado3)
                {
                    MessageBox.Show("Triângulo Equilátero!");
                }
                else
                    MessageBox.Show("Triângulo Isóceles!");

            }
            else
            {
                MessageBox.Show("Falta Informações de Entrada!");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtL1.Clear();
            txtL2.Clear();
            txtL3.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtL1_TextChanged(object sender, EventArgs e)
        {
            this.Focus();
        }
    }
}
