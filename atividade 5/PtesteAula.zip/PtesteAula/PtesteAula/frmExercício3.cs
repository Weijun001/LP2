﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteAula
{
    public partial class frmExercício3 : Form
    {
        public frmExercício3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string textoEntrada, textoSemEspaco, reverso;

            textoEntrada = txtTexto.Text.ToUpper();
            textoSemEspaco = textoEntrada.Replace(" ", "");

            reverso = new string(textoSemEspaco.Reverse().ToArray());

            if (textoSemEspaco == reverso)
            {
                MessageBox.Show("É um Palíndromo!");
            }
            else
                MessageBox.Show("Não é um Palíndromo!");
        }
    }
}
