﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteAula
{
    public partial class frmExercício2 : Form
    {
        public frmExercício2()
        {
            InitializeComponent();
        }

        private void formExercício2_Load(object sender, EventArgs e)
        {

        }

        private void btnH_Click(object sender, EventArgs e)
        {
            int contador;
            double N, H=1, resultado=0;

            if (double.TryParse(txtN.Text, out N))
            {
                if (N > 0)
                {
                    for (contador = 1; contador <= N; contador++)
                    {
                        resultado = resultado + (H / contador);
                    }

                    MessageBox.Show("O Resultado é: " +
                        resultado.ToString());
                }
                
                else
                    MessageBox.Show("Número N deve ser maior que zero!");
            }
            
            else
                MessageBox.Show("Somente Números!");
        }
    }
}
