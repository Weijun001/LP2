﻿namespace PtesteAula
{
    partial class frmExercício1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxt = new System.Windows.Forms.RichTextBox();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnPares = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxt
            // 
            this.rchTxt.Location = new System.Drawing.Point(114, 43);
            this.rchTxt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rchTxt.MaxLength = 100;
            this.rchTxt.Name = "rchTxt";
            this.rchTxt.Size = new System.Drawing.Size(548, 117);
            this.rchTxt.TabIndex = 0;
            this.rchTxt.Text = "";
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.Location = new System.Drawing.Point(32, 240);
            this.btnEspacoBranco.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(188, 90);
            this.btnEspacoBranco.TabIndex = 1;
            this.btnEspacoBranco.Text = "Quantidade de Espaços em Branco";
            this.btnEspacoBranco.UseVisualStyleBackColor = true;
            this.btnEspacoBranco.Click += new System.EventHandler(this.btnEspacoBranco_Click);
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(286, 240);
            this.btnR.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(188, 90);
            this.btnR.TabIndex = 2;
            this.btnR.Text = "Quantidade de letras \"R\"";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.btnR_Click);
            // 
            // btnPares
            // 
            this.btnPares.Location = new System.Drawing.Point(550, 240);
            this.btnPares.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnPares.Name = "btnPares";
            this.btnPares.Size = new System.Drawing.Size(188, 90);
            this.btnPares.TabIndex = 3;
            this.btnPares.Text = "Quantidade de Pares de  letras ";
            this.btnPares.UseVisualStyleBackColor = true;
            this.btnPares.Click += new System.EventHandler(this.btnPares_Click);
            // 
            // frmExercício1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1066, 554);
            this.Controls.Add(this.btnPares);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.rchTxt);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmExercício1";
            this.Text = "formExercício1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxt;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnPares;
    }
}