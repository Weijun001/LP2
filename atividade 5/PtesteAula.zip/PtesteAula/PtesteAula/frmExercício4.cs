﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteAula
{
    public partial class frmExercício4 : Form
    {
        public frmExercício4()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            double salario, producao, gratificacao, salarioBruto, A=0, B=0, C=0, D=0;

            txtNome.Text = txtNome.Text.ToUpper();

            if ((txtNome.Text != string.Empty) &&
                (txtCodigo.Text != string.Empty) &&
                (txtCargo.Text != string.Empty))
            {
                if (txtCargo.Text == "1")
                {
                    salario = 2000;
                    A = salario;
                    txtSalario.Text = salario.ToString();
                }

                else
                 if (txtCargo.Text == "2")
                {
                    salario = 2500;
                    A = salario;
                    txtSalario.Text = salario.ToString();
                }

                else
                 if (txtCargo.Text == "3")
                {
                    salario = 3000;
                    A = salario;
                    txtSalario.Text = salario.ToString();
                }

                else
                    MessageBox.Show("Gargo Inexistente!");


                if (double.TryParse(txtProducao.Text, out producao) &&
                    double.TryParse(txtGratificacao.Text, out gratificacao))
                {
                    if (producao >= 100)
                    {
                        B = 1;
                    }


                    if (producao >= 120)
                    {
                        C = 1;
                    }


                    if (producao >= 150)
                    {
                        D = 1;
                    }

                    salarioBruto = A + (A * ((0.05 * B) + (0.1 * C) + (0.1 * D))) + gratificacao;

                    if (salarioBruto >= 7000 && producao < 150)
                    {
                        MessageBox.Show("Salário incompatível ao cargo!");
                    }
                    else
                        TxtSalarioBruto.Text = salarioBruto.ToString();
                }
            }
            else
                MessageBox.Show("Falta dados de entrada!");
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
            Focus();
        }
    }
}