﻿namespace PtesteAula
{
    partial class frmExercício2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtN = new System.Windows.Forms.TextBox();
            this.lblN = new System.Windows.Forms.Label();
            this.btnH = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtN
            // 
            this.txtN.Location = new System.Drawing.Point(290, 47);
            this.txtN.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(164, 26);
            this.txtN.TabIndex = 0;
            // 
            // lblN
            // 
            this.lblN.AutoSize = true;
            this.lblN.Location = new System.Drawing.Point(148, 54);
            this.lblN.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblN.Name = "lblN";
            this.lblN.Size = new System.Drawing.Size(86, 19);
            this.lblN.TabIndex = 1;
            this.lblN.Text = "Número N";
            // 
            // btnH
            // 
            this.btnH.Location = new System.Drawing.Point(152, 163);
            this.btnH.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnH.Name = "btnH";
            this.btnH.Size = new System.Drawing.Size(125, 48);
            this.btnH.TabIndex = 2;
            this.btnH.Text = "Número H";
            this.btnH.UseVisualStyleBackColor = true;
            this.btnH.Click += new System.EventHandler(this.btnH_Click);
            // 
            // frmExercício2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1333, 658);
            this.Controls.Add(this.btnH);
            this.Controls.Add(this.lblN);
            this.Controls.Add(this.txtN);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "frmExercício2";
            this.Text = "formExercício2";
            this.Load += new System.EventHandler(this.formExercício2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.Label lblN;
        private System.Windows.Forms.Button btnH;
    }
}