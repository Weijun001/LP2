﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PtesteAula
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio1"];

            if (fc != null)
                fc.Close();

            frmExercício1 FrmExercício1 = new frmExercício1();
            FrmExercício1.MdiParent = this;
            FrmExercício1.WindowState = FormWindowState.Maximized;
            FrmExercício1.Show();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio2"];

            if (fc != null)
                fc.Close();

            frmExercício2 FrmExercício2 = new frmExercício2();
            FrmExercício2.MdiParent = this;
            FrmExercício2.WindowState = FormWindowState.Maximized;
            FrmExercício2.Show();
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio3"];

            if (fc != null)
                fc.Close();

            frmExercício3 FrmExercício3 = new frmExercício3();
            FrmExercício3.MdiParent = this;
            FrmExercício3.WindowState = FormWindowState.Maximized;
            FrmExercício3.Show();
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio4"];

            if (fc != null)
                fc.Close();

            frmExercício4 FrmExercício4 = new frmExercício4();
            FrmExercício4.MdiParent = this;
            FrmExercício4.WindowState = FormWindowState.Maximized;
            FrmExercício4.Show();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio1"];

            if (fc != null)
                fc.Close();

            frmExercício1 FrmExercício1 = new frmExercício1();
            FrmExercício1.MdiParent = this;
            FrmExercício1.WindowState = FormWindowState.Maximized;
            FrmExercício1.Show();
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio2"];

            if (fc != null)
                fc.Close();

            frmExercício2 FrmExercício2 = new frmExercício2();
            FrmExercício2.MdiParent = this;
            FrmExercício2.WindowState = FormWindowState.Maximized;
            FrmExercício2.Show();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio3"];

            if (fc != null)
                fc.Close();

            frmExercício3 FrmExercício3 = new frmExercício3();
            FrmExercício3.MdiParent = this;
            FrmExercício3.WindowState = FormWindowState.Maximized;
            FrmExercício3.Show();
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio4"];

            if (fc != null)
                fc.Close();

            frmExercício4 FrmExercício4 = new frmExercício4();
            FrmExercício4.MdiParent = this;
            FrmExercício4.WindowState = FormWindowState.Maximized;
            FrmExercício4.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
