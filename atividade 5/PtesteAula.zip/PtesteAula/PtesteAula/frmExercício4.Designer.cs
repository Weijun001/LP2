﻿namespace PtesteAula
{
    partial class frmExercício4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LblProducao = new System.Windows.Forms.Label();
            this.LblSalario = new System.Windows.Forms.Label();
            this.LblGratificacao = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.txtProducao = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtGratificacao = new System.Windows.Forms.TextBox();
            this.TxtSalarioBruto = new System.Windows.Forms.TextBox();
            this.LblSalarioBruto = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 91);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Cargo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(60, 157);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Código:";
            // 
            // LblProducao
            // 
            this.LblProducao.AutoSize = true;
            this.LblProducao.Location = new System.Drawing.Point(451, 31);
            this.LblProducao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblProducao.Name = "LblProducao";
            this.LblProducao.Size = new System.Drawing.Size(71, 20);
            this.LblProducao.TabIndex = 3;
            this.LblProducao.Text = "Produção:";
            // 
            // LblSalario
            // 
            this.LblSalario.AutoSize = true;
            this.LblSalario.Location = new System.Drawing.Point(451, 160);
            this.LblSalario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblSalario.Name = "LblSalario";
            this.LblSalario.Size = new System.Drawing.Size(54, 20);
            this.LblSalario.TabIndex = 4;
            this.LblSalario.Text = "Salário:";
            // 
            // LblGratificacao
            // 
            this.LblGratificacao.AutoSize = true;
            this.LblGratificacao.Location = new System.Drawing.Point(451, 96);
            this.LblGratificacao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblGratificacao.Name = "LblGratificacao";
            this.LblGratificacao.Size = new System.Drawing.Size(82, 20);
            this.LblGratificacao.TabIndex = 5;
            this.LblGratificacao.Text = "Gratificação:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(169, 25);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(132, 26);
            this.txtNome.TabIndex = 6;
            this.txtNome.TextChanged += new System.EventHandler(this.txtNome_TextChanged);
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(169, 88);
            this.txtCargo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(132, 26);
            this.txtCargo.TabIndex = 7;
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(169, 152);
            this.txtCodigo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(132, 26);
            this.txtCodigo.TabIndex = 8;
            // 
            // txtProducao
            // 
            this.txtProducao.Location = new System.Drawing.Point(574, 25);
            this.txtProducao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtProducao.Name = "txtProducao";
            this.txtProducao.Size = new System.Drawing.Size(132, 26);
            this.txtProducao.TabIndex = 9;
            // 
            // txtSalario
            // 
            this.txtSalario.Enabled = false;
            this.txtSalario.Location = new System.Drawing.Point(574, 151);
            this.txtSalario.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(132, 26);
            this.txtSalario.TabIndex = 10;
            // 
            // txtGratificacao
            // 
            this.txtGratificacao.Location = new System.Drawing.Point(574, 85);
            this.txtGratificacao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtGratificacao.Name = "txtGratificacao";
            this.txtGratificacao.Size = new System.Drawing.Size(132, 26);
            this.txtGratificacao.TabIndex = 11;
            // 
            // TxtSalarioBruto
            // 
            this.TxtSalarioBruto.Enabled = false;
            this.TxtSalarioBruto.Location = new System.Drawing.Point(574, 302);
            this.TxtSalarioBruto.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TxtSalarioBruto.Name = "TxtSalarioBruto";
            this.TxtSalarioBruto.Size = new System.Drawing.Size(132, 26);
            this.TxtSalarioBruto.TabIndex = 13;
            // 
            // LblSalarioBruto
            // 
            this.LblSalarioBruto.AutoSize = true;
            this.LblSalarioBruto.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSalarioBruto.Location = new System.Drawing.Point(413, 309);
            this.LblSalarioBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblSalarioBruto.Name = "LblSalarioBruto";
            this.LblSalarioBruto.Size = new System.Drawing.Size(115, 19);
            this.LblSalarioBruto.TabIndex = 12;
            this.LblSalarioBruto.Text = "Salário Bruto:";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.Location = new System.Drawing.Point(96, 273);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(148, 84);
            this.btnVerificar.TabIndex = 14;
            this.btnVerificar.Text = "Verificar Salário Bruto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.BtnVerificar_Click);
            // 
            // frmExercício4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 692);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.TxtSalarioBruto);
            this.Controls.Add(this.LblSalarioBruto);
            this.Controls.Add(this.txtGratificacao);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtProducao);
            this.Controls.Add(this.txtCodigo);
            this.Controls.Add(this.txtCargo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.LblGratificacao);
            this.Controls.Add(this.LblSalario);
            this.Controls.Add(this.LblProducao);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmExercício4";
            this.Text = "frmExercício4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label LblProducao;
        private System.Windows.Forms.Label LblSalario;
        private System.Windows.Forms.Label LblGratificacao;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.TextBox txtProducao;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtGratificacao;
        private System.Windows.Forms.TextBox TxtSalarioBruto;
        private System.Windows.Forms.Label LblSalarioBruto;
        private System.Windows.Forms.Button btnVerificar;
    }
}