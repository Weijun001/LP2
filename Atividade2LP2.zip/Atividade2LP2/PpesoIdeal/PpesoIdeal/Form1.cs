﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PpesoIdeal
{
    public partial class Form1 : Form
    {
        double altura, peso, resultado;
        private void txtAltura_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
            txtResultado.Clear();
        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {
            this.Focus();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (double.TryParse(txtAltura.Text, out altura) &&
                double.TryParse(txtPeso.Text, out peso) &&
                rdbtnFem.Checked)
            {
                resultado = ((62.1 * altura) - 44.7);
                resultado = Math.Round(resultado, 2);
                txtResultado.Text = resultado.ToString();

                if (resultado < peso)
                {
                    MessageBox.Show("Peso acima do ideal!");
                }

                else
                    if (peso == resultado)
                {
                    MessageBox.Show("Peso ideal!");
                }

                else
                {
                    MessageBox.Show("Peso abaixo do ideal!");
                }
            }

            else
            {
                if (double.TryParse(txtAltura.Text, out altura) &&
                    double.TryParse(txtPeso.Text, out peso) &&
                    rdbtnMasc.Checked)
                {
                    resultado = ((72.7 * altura) - 58);
                    resultado = Math.Round(resultado, 2);
                    txtResultado.Text = resultado.ToString();

                    if (resultado < peso)
                    {
                        MessageBox.Show("Peso acima do ideal!");
                    }

                    else
                        if (peso == resultado)
                    {
                        MessageBox.Show("Peso ideal!");
                    }

                    else
                    {
                        MessageBox.Show("Peso abaixo do ideal!");
                    }
                }
                else
                {
                    MessageBox.Show("Falta Informações de Entrada!");
                }

            }
        }
    }
}
