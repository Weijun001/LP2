﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Globalization;

namespace PAtividade
{
    //Nome: Weijun Yu
    //Ra: 0030482013028 --> 8 Meses
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[8, 4];
            string aux = "";
            double totMes1 = 0, totMes2 = 0, totMes3 = 0, totMes4 = 0, totMes5 = 0, totMes6 = 0,
                totMes7 = 0, totMes8 = 0, totSemanal = 0, total = 0;

            lstBox.Items.Add("--x RESULTADO DAS VENDAS x-- ");
            lstBox.Items.Add(" ");

            for (var i = 0; i < 8; i++)
            {
                for (var j = 0; j < 4; j++)
                {
                    aux = Interaction.InputBox("Mês: " +
                        (i + 1).ToString() + " Semana: " + (j + 1).ToString(),
                        "Entrada de Valores");

                    if ((double.TryParse(aux, out matriz[i, j])) &&
                        (matriz[i, j] >= 0))
                    {
                        total += matriz[i, j];
                        totSemanal = matriz[i, j];
                        lstBox.Items.Add("Mês: " + (i + 1) + " " + "/" + "Semana: " + (j + 1) + " " + "= " + totSemanal.ToString("C2", CultureInfo.CurrentCulture) + "\n");
                        lstBox.Items.Add(" ");
                    }

                    else
                    {
                        MessageBox.Show("---> Valor Inválida <---");
                        j--;
                    }

                    totMes1 = matriz[0, 0] + matriz[0, 1] + matriz[0, 2] + matriz[0, 3];
                    totMes2 = matriz[1, 0] + matriz[1, 1] + matriz[1, 2] + matriz[1, 3];
                    totMes3 = matriz[2, 0] + matriz[2, 1] + matriz[2, 2] + matriz[2, 3];
                    totMes4 = matriz[3, 0] + matriz[3, 1] + matriz[3, 2] + matriz[3, 3];
                    totMes5 = matriz[4, 0] + matriz[4, 1] + matriz[4, 2] + matriz[4, 3];
                    totMes6 = matriz[5, 0] + matriz[5, 1] + matriz[5, 2] + matriz[5, 3];
                    totMes7 = matriz[6, 0] + matriz[6, 1] + matriz[6, 2] + matriz[6, 3];
                    totMes8 = matriz[7, 0] + matriz[7, 1] + matriz[7, 2] + matriz[7, 3];
                }
            }

            lstBox.Items.Add(" ");
            lstBox.Items.Add("Total do Mês 1 = " + totMes1.ToString("C2", CultureInfo.CurrentCulture) + "\n");
            lstBox.Items.Add(" ");
            lstBox.Items.Add("Total do Mês 2 = " + totMes2.ToString("C2", CultureInfo.CurrentCulture) + "\n");
            lstBox.Items.Add(" ");
            lstBox.Items.Add("Total do Mês 3 = " + totMes3.ToString("C2", CultureInfo.CurrentCulture) + "\n");
            lstBox.Items.Add(" ");
            lstBox.Items.Add("Total do Mês 4 = " + totMes4.ToString("C2", CultureInfo.CurrentCulture) + "\n");
            lstBox.Items.Add(" ");
            lstBox.Items.Add("Total do Mês 5 = " + totMes5.ToString("C2", CultureInfo.CurrentCulture) + "\n");
            lstBox.Items.Add(" ");
            lstBox.Items.Add("Total do Mês 6 = " + totMes6.ToString("C2", CultureInfo.CurrentCulture) + "\n");
            lstBox.Items.Add(" ");
            lstBox.Items.Add("Total do Mês 7 = " + totMes7.ToString("C2", CultureInfo.CurrentCulture) + "\n");
            lstBox.Items.Add(" ");
            lstBox.Items.Add("Total do Mês 8 = " + totMes8.ToString("C2", CultureInfo.CurrentCulture) + "\n");
            lstBox.Items.Add("---------------------------------------------------");
            lstBox.Items.Add("TOTAL GERAL ---> "+ total.ToString("C2", CultureInfo.CurrentCulture) + "\n");
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
