﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExerc1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (var i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox("Digite um número:" + (i + 1).ToString(),
                    "Entrada de Dados");

                if (!(int.TryParse(aux, out vetor[i])))
                {
                    MessageBox.Show("Número Inválido!!!");
                    i--;
                }
            }

            aux = "";

            for (var i = vetor.Length - 1; i >= 0; i--)
                aux += vetor[i].ToString() + "\n";

            MessageBox.Show(aux);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExerc6_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[20, 3];
            string aux = "";
            double media = 0;

            for (var i = 0; i < 20; i++)
            {
                media = 0;

                for (var j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox("Entre com a nota " +
                        (j + 1).ToString() + " do aluno " + (i + 1).ToString(),
                        "Entrada de notas");

                    if ((double.TryParse(aux, out matriz[i, j])) &&
                        (matriz[i, j] >= 0) && (matriz[i, j] <= 10))
                    {
                        media += matriz[i, j];
                    }

                    else
                    {
                        MessageBox.Show("Nota Inválida!!!");
                        j--;
                    }
                }

                MessageBox.Show("Aluno" + (i + 1).ToString() + "média" +
                    (media / 3).ToString("N2"));
            }
        }

        private void btnExerc2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox("Digite o número " + (i + 1).ToString() + ": ");

                if (!(int.TryParse(aux, out vetor[i])))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);

            aux = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                aux += vetor[i].ToString() + "\n";
            }

            MessageBox.Show(aux);
        }

        private void btnExerc3_Click(object sender, EventArgs e)
        {
            double[] qtd = new double[10];
            double[] valor = new double[10];

            bool qtdOk = false;

            string aux = "";

            for (int i = 0; i < qtd.Length; i++)
            {
                if (!qtdOk)
                {
                    aux = Interaction.InputBox("Digite a quantidade do produto " + (i + 1).ToString() + ": ");

                    if (!(double.TryParse(aux, out qtd[i])))
                    {
                        MessageBox.Show("Quantidade inválida!");
                        i--;
                    }
                    else
                    {
                        qtdOk = true;
                    }
                }

                aux = Interaction.InputBox("Digite o valor do produto " + (i + 1).ToString() + ": ");

                if (!(double.TryParse(aux, out valor[i])))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
                else
                {
                    qtdOk = false;
                }
            }

            double faturamento = 0;

            for (int i = 0; i < qtd.Length; i++)
            {
                faturamento += qtd[i] * valor[i];
            }

            MessageBox.Show("Faturamento do mês: R$ " + faturamento.ToString("N2"));
        }

        private void btnExerc4_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };

            int total = 0;

            for (int i = 0; i < Alunos.Length - 1; i++)
            {
                total += Alunos[i].Length;
            }

            MessageBox.Show(total.ToString());
        }

        private void btnExerc5_Click(object sender, EventArgs e)
        {
            ArrayList arr = new ArrayList();

            arr.Add("Ana");
            arr.Add("André");
            arr.Add("Débora");
            arr.Add("Fátima");
            arr.Add("João");
            arr.Add("Janete");
            arr.Add("Otávio");
            arr.Add("Marcelo");
            arr.Add("Pedro");
            arr.Add("Thais");

            arr.Remove("Otávio");

            string texto = "";

            for (int i = 0; i < arr.Count; i++)
            {
                texto += arr[i] + "\n";
            }

            MessageBox.Show(texto);
        }
    }
}
