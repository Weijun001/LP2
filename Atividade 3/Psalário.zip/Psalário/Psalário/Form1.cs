﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalário
{
    public partial class Form1 : Form
    {
        double descINSS, descIRPF, salarioBruto, numFilhos, salarioFamilia, salarioLiquido;
        char nome;
        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtDados_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtNumFilhos_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
            txtNome.Focus();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtSalário.Clear();
            txtNumFilhos.Clear();
        }


        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (rdbtnF.Checked && CkbCasado.Checked == true)
            {
                txtDados.Text = "Srª: " + txtNome.Text.ToString() + "      " + "Número de filhos: " + txtNumFilhos.Text.ToString() + "     " + "Estado Civil: Casada";
            }

            else 
                if (rdbtnF.Checked && CkbCasado.Checked == false)
            {
                txtDados.Text = "Srª: " + txtNome.Text.ToString() + "      " + "Número de filhos: " + txtNumFilhos.Text.ToString() + "      " + "Estado Civil: Solteira";
            }

            else
                if (rdbtnM.Checked && CkbCasado.Checked == true)
            {
                txtDados.Text = "Srº: " + txtNome.Text.ToString() + "      "  + "Número de filhos: " + txtNumFilhos.Text.ToString() + "      " + "Estado Civil: Casado";
            }

            else
                 if (rdbtnM.Checked && CkbCasado.Checked == false)
            {
                txtDados.Text = "Srº: " + txtNome.Text.ToString() + "       " + "Número de filhos: " + txtNumFilhos.Text.ToString() + "      " + "Estado Civil: Solteirto";
            }


            if(double.TryParse(txtSalário.Text, out salarioBruto) &&
               double.TryParse(txtNumFilhos.Text, out numFilhos) &
               rdbtnF.Checked ||
               rdbtnM.Checked)
            {
                if (salarioBruto <= 800.47)
                {
                    txtAliquotaINSS.Text = "7,65%";
                    descINSS = salarioBruto * 0.0765;
                    txtDescINSS.Text = descINSS.ToString();
                }

                else
                    if (salarioBruto > 880.47 && salarioBruto <= 1000.50)
                {
                    txtAliquotaINSS.Text = "8,65%";
                    descINSS = salarioBruto * 0.0865;
                    txtDescINSS.Text = descINSS.ToString();
                }

                else
                    if (salarioBruto > 1000.50 && salarioBruto <= 1400.77)
                {
                    txtAliquotaINSS.Text = "9%";
                    descINSS = salarioBruto * 0.09;
                    txtDescINSS.Text = descINSS.ToString();
                }

                else
                    if (salarioBruto > 1400.77 && salarioBruto <= 2801.56)
                {
                    txtAliquotaINSS.Text = "11%";
                    descINSS = salarioBruto * 0.11;
                    txtDescINSS.Text = descINSS.ToString();
                }

                else
                    if (salarioBruto > 2801.56)
                {
                    txtAliquotaINSS.Text = "Teto";
                    descINSS = 308.17;
                    txtDescINSS.Text = descINSS.ToString();
                }


                if (double.TryParse(txtSalário.Text, out salarioBruto) &&
                    double.TryParse(txtNumFilhos.Text, out numFilhos) &&
                    rdbtnF.Checked ||
                    rdbtnM.Checked)

                    if (salarioBruto <= 1257.12)
                    {
                        txtAliquotaIRPF.Text = "Isento";
                        descIRPF = 0;
                        txtDescIRPF.Text = descIRPF.ToString();
                    }

                    else
                        if (salarioBruto > 1257.12 && salarioBruto < 2512.08)
                    {
                        txtAliquotaIRPF.Text = "15%";
                        descIRPF = salarioBruto * 0.15;
                        txtDescIRPF.Text = descIRPF.ToString();
                    }

                    else
                        if (salarioBruto > 2512.08)
                    {
                        txtAliquotaIRPF.Text = "27,5%";
                        descIRPF = salarioBruto * 0.275;
                        txtDescIRPF.Text = descIRPF.ToString();
                    }


                if (salarioBruto <= 435.52)
                {
                    salarioFamilia = numFilhos * 22.33;
                    txtSalFamília.Text = salarioFamilia.ToString();
                }

                else
                    if (salarioBruto > 435.52 && salarioBruto < 654.61)
                {
                    salarioFamilia = numFilhos * 15.74;
                    txtSalFamília.Text = salarioFamilia.ToString();
                }

                else
                    if (salarioBruto > 654.61)
                {
                    salarioFamilia = 0;
                    txtSalFamília.Text = salarioFamilia.ToString();
                }

                {
                    salarioLiquido = salarioBruto - descINSS - descIRPF + salarioFamilia;
                    txtSalLíquido.Text = salarioLiquido.ToString();

                }

            }
            else
            {
                MessageBox.Show("Falta informações de entrada! \n OU \n Informações inválidas!");
            }



        }
}
}
