﻿namespace Psalário
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblAlíquotaIRPF = new System.Windows.Forms.Label();
            this.lblAlíquotaINSS = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblSalFamília = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.rdbtnF = new System.Windows.Forms.RadioButton();
            this.rdbtnM = new System.Windows.Forms.RadioButton();
            this.CkbCasado = new System.Windows.Forms.CheckBox();
            this.txtAliquotaINSS = new System.Windows.Forms.TextBox();
            this.txtAliquotaIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamília = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.txtSalLíquido = new System.Windows.Forms.TextBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtDados = new System.Windows.Forms.TextBox();
            this.btnFechar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.txtNumFilhos = new System.Windows.Forms.TextBox();
            this.txtSalário = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(26, 39);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(162, 18);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do Funcionário:";
            // 
            // lblAlíquotaIRPF
            // 
            this.lblAlíquotaIRPF.AutoSize = true;
            this.lblAlíquotaIRPF.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlíquotaIRPF.Location = new System.Drawing.Point(35, 350);
            this.lblAlíquotaIRPF.Name = "lblAlíquotaIRPF";
            this.lblAlíquotaIRPF.Size = new System.Drawing.Size(107, 18);
            this.lblAlíquotaIRPF.TabIndex = 1;
            this.lblAlíquotaIRPF.Text = "Alíquota IRPF:";
            // 
            // lblAlíquotaINSS
            // 
            this.lblAlíquotaINSS.AutoSize = true;
            this.lblAlíquotaINSS.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlíquotaINSS.Location = new System.Drawing.Point(31, 289);
            this.lblAlíquotaINSS.Name = "lblAlíquotaINSS";
            this.lblAlíquotaINSS.Size = new System.Drawing.Size(108, 18);
            this.lblAlíquotaINSS.TabIndex = 2;
            this.lblAlíquotaINSS.Text = "Alíquota INSS:";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumFilhos.Location = new System.Drawing.Point(26, 145);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(126, 18);
            this.lblNumFilhos.TabIndex = 3;
            this.lblNumFilhos.Text = "Número de fihos:";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalBruto.Location = new System.Drawing.Point(26, 88);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(103, 18);
            this.lblSalBruto.TabIndex = 4;
            this.lblSalBruto.Text = "Salário Bruto:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(462, 286);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 18);
            this.label5.TabIndex = 5;
            this.label5.Text = "Desconto INSS:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(462, 405);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(117, 18);
            this.label7.TabIndex = 7;
            this.label7.Text = "Salário Líquido:";
            // 
            // lblSalFamília
            // 
            this.lblSalFamília.AutoSize = true;
            this.lblSalFamília.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalFamília.Location = new System.Drawing.Point(36, 404);
            this.lblSalFamília.Name = "lblSalFamília";
            this.lblSalFamília.Size = new System.Drawing.Size(117, 18);
            this.lblSalFamília.TabIndex = 8;
            this.lblSalFamília.Text = "Salário Família:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(439, 35);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 19);
            this.label9.TabIndex = 9;
            this.label9.Text = "Sexo:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(462, 347);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 18);
            this.label10.TabIndex = 10;
            this.label10.Text = "Desconto IRPF:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(209, 37);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 13;
            this.txtNome.TextChanged += new System.EventHandler(this.txtNome_TextChanged);
            // 
            // rdbtnF
            // 
            this.rdbtnF.AutoSize = true;
            this.rdbtnF.Checked = true;
            this.rdbtnF.Location = new System.Drawing.Point(443, 67);
            this.rdbtnF.Name = "rdbtnF";
            this.rdbtnF.Size = new System.Drawing.Size(31, 17);
            this.rdbtnF.TabIndex = 14;
            this.rdbtnF.TabStop = true;
            this.rdbtnF.Text = "F";
            this.rdbtnF.UseVisualStyleBackColor = true;
            // 
            // rdbtnM
            // 
            this.rdbtnM.AutoSize = true;
            this.rdbtnM.Location = new System.Drawing.Point(443, 99);
            this.rdbtnM.Name = "rdbtnM";
            this.rdbtnM.Size = new System.Drawing.Size(34, 17);
            this.rdbtnM.TabIndex = 15;
            this.rdbtnM.Text = "M";
            this.rdbtnM.UseVisualStyleBackColor = true;
            // 
            // CkbCasado
            // 
            this.CkbCasado.AutoSize = true;
            this.CkbCasado.Location = new System.Drawing.Point(443, 148);
            this.CkbCasado.Name = "CkbCasado";
            this.CkbCasado.Size = new System.Drawing.Size(62, 17);
            this.CkbCasado.TabIndex = 16;
            this.CkbCasado.Text = "Casado";
            this.CkbCasado.UseVisualStyleBackColor = true;
            // 
            // txtAliquotaINSS
            // 
            this.txtAliquotaINSS.Enabled = false;
            this.txtAliquotaINSS.Location = new System.Drawing.Point(159, 286);
            this.txtAliquotaINSS.Name = "txtAliquotaINSS";
            this.txtAliquotaINSS.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaINSS.TabIndex = 17;
            // 
            // txtAliquotaIRPF
            // 
            this.txtAliquotaIRPF.Enabled = false;
            this.txtAliquotaIRPF.Location = new System.Drawing.Point(159, 347);
            this.txtAliquotaIRPF.Name = "txtAliquotaIRPF";
            this.txtAliquotaIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaIRPF.TabIndex = 18;
            // 
            // txtSalFamília
            // 
            this.txtSalFamília.Enabled = false;
            this.txtSalFamília.Location = new System.Drawing.Point(159, 402);
            this.txtSalFamília.Name = "txtSalFamília";
            this.txtSalFamília.Size = new System.Drawing.Size(100, 20);
            this.txtSalFamília.TabIndex = 19;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(609, 284);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDescINSS.TabIndex = 20;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(609, 347);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtDescIRPF.TabIndex = 21;
            // 
            // txtSalLíquido
            // 
            this.txtSalLíquido.Enabled = false;
            this.txtSalLíquido.Location = new System.Drawing.Point(609, 403);
            this.txtSalLíquido.Name = "txtSalLíquido";
            this.txtSalLíquido.Size = new System.Drawing.Size(100, 20);
            this.txtSalLíquido.TabIndex = 22;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnVerificar.Location = new System.Drawing.Point(633, 18);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(125, 53);
            this.btnVerificar.TabIndex = 23;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // txtDados
            // 
            this.txtDados.Enabled = false;
            this.txtDados.Location = new System.Drawing.Point(29, 211);
            this.txtDados.Multiline = true;
            this.txtDados.Name = "txtDados";
            this.txtDados.Size = new System.Drawing.Size(345, 35);
            this.txtDados.TabIndex = 24;
            this.txtDados.TextChanged += new System.EventHandler(this.txtDados_TextChanged);
            // 
            // btnFechar
            // 
            this.btnFechar.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btnFechar.Location = new System.Drawing.Point(633, 168);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(125, 41);
            this.btnFechar.TabIndex = 25;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnLimpar.Location = new System.Drawing.Point(633, 99);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(125, 42);
            this.btnLimpar.TabIndex = 26;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // txtNumFilhos
            // 
            this.txtNumFilhos.Location = new System.Drawing.Point(209, 143);
            this.txtNumFilhos.Name = "txtNumFilhos";
            this.txtNumFilhos.Size = new System.Drawing.Size(100, 20);
            this.txtNumFilhos.TabIndex = 27;
            // 
            // txtSalário
            // 
            this.txtSalário.Location = new System.Drawing.Point(209, 86);
            this.txtSalário.Name = "txtSalário";
            this.txtSalário.Size = new System.Drawing.Size(100, 20);
            this.txtSalário.TabIndex = 28;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtSalário);
            this.Controls.Add(this.txtNumFilhos);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.txtDados);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.txtSalLíquido);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalFamília);
            this.Controls.Add(this.txtAliquotaIRPF);
            this.Controls.Add(this.txtAliquotaINSS);
            this.Controls.Add(this.CkbCasado);
            this.Controls.Add(this.rdbtnM);
            this.Controls.Add(this.rdbtnF);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblSalFamília);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblAlíquotaINSS);
            this.Controls.Add(this.lblAlíquotaIRPF);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblAlíquotaIRPF;
        private System.Windows.Forms.Label lblAlíquotaINSS;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblSalFamília;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.RadioButton rdbtnF;
        private System.Windows.Forms.RadioButton rdbtnM;
        private System.Windows.Forms.CheckBox CkbCasado;
        private System.Windows.Forms.TextBox txtAliquotaINSS;
        private System.Windows.Forms.TextBox txtAliquotaIRPF;
        private System.Windows.Forms.TextBox txtSalFamília;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.TextBox txtSalLíquido;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtDados;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.TextBox txtNumFilhos;
        private System.Windows.Forms.TextBox txtSalário;
    }
}

